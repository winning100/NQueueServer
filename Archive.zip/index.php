
<html> <head>
<title>Bob’s Auto Parts - Order Results</title> </head>
<body>
<h1>Bob’s Auto Parts</h1> <h2>Order Results</h2> 
<form action="check_in.php" method="post">
Client id: <input type=“text” name="client_id"> <br>
Restaurant id: <input type="text" name="restaurant_id"><br>
phone: <input type="text" name="phone_number"><br>
<input type="submit" value="check in">

</form>

</body>
</html>
